'use strict';

angular.module('personalAssistant', ['ui.router', 'ngAnimate', 'ui.bootstrap', 'ngMessages', 'appServices', 'doctorServices', 'ngTable', 'oitozero.ngSweetAlert']);


